function callCrudAction(action,id) {
	alert(action);
	alert(id);
	var queryString;
	switch(action) {
		case "SubsCourse":			
			queryString = 'action='+action+'&course_id='+id;
		break;
		case "unsubsCourse":			
			queryString = 'action='+action+'&course_id='+id;
		break;		
	}	
	jQuery.ajax({
	url: "control/pAction.php",
	data:queryString,
	type: "POST",
	success:function(data){
		switch(action) {
			case "SubsCourse":
			$("#course_subs").hide();
			$("#course_cancel").show();
			break;
			case "unsubsCourse":
			$("#course_cancel").hide();
			$("#course_subs").show();
			break;			
		}
		
		
	},
	error:function (){}
	});
}
