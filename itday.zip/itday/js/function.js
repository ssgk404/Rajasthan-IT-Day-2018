function openNav() {
    document.getElementById("navLft").style.width = "250px";
	$(".hmDvWd").css({"margin": "3% 10% 0 20%", "background": "#fff"});
}

function closeNav() {
    document.getElementById("navLft").style.width = "0";	
		$(".hmDvWd").css({"margin": "3% 10% 0 5%", "background": "#fff"});
   
}

$(document).ready(function(){
    $("#home_").click(function(){
		$("#home").show();
		$("#courses").hide();
		$("#subscription").hide();
		$("#certificate").hide();
		$("#hmDvWdCrcVew").slideUp().hide();		
    });
	$("#courses_").click(function(){
		$("#home").hide();
		$("#courses").show();
		$("#subscription").hide();
		$("#certificate").hide();
		$("#hmDvWdCrcVew").slideUp().hide();
    });
	$("#subscription_").click(function(){
        $("#home").hide();
		$("#courses").hide();
		$("#subscription").show();
		$("#certificate").hide();
		$("#hmDvWdCrcVew").slideUp().hide();
    });
	$("#certificate_").click(function(){
        $("#home").hide();
		$("#courses").hide();
		$("#subscription").hide();
		$("#certificate").show();
		$("#hmDvWdCrcVew").slideUp().hide();
    });
    
});