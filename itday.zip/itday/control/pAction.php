<?php
error_reporting(E_ERROR | E_PARSE);
require_once("../config.php");
$db_handle = new DBController();
$date = date("j-M-y h:i a");
$action = $_POST["action"];
$ip = $_SERVER['REMOTE_ADDR'];

if(!empty($action)) {
	switch($action) {
		case "SubsCourse":
			$que = "insert into subscription (course_id, user_id, date_time) values ('".$_POST["course_id"]."', '2017107', '$date')";
			$db_handle->runQuery($que);
			break;
			case "unsubsCourse":
			$que = "delete from subscription where course_id='".$_POST["course_id"]."' and user_id='2017107'";
			$db_handle->runQuery($que);
			break;			
		}		
	}				
?>