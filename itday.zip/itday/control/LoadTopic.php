<?php
error_reporting(E_ERROR | E_PARSE);
require_once("../config.php");
$db_handle = new DBController();
	$que = "SELECT * FROM topic_content where topic_id='".$_POST["course_heading"]."'";
	$que2 = $db_handle->runQuery($que);
	if($que2)
	{
		echo nl2br($que2);
	}
	else
	{
		echo 'Something went wrong. Please try again !!';
	}

					
?>